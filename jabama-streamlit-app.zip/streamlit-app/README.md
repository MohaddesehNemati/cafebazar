# داشبورد تحلیل نظرات کافه‌بازار جاباما

## اجرای محلی
```
pip install -r requirements.txt
streamlit run app.py
```

## پابلیش روی Streamlit Community Cloud
1. این سه فایل (`app.py`، `dashboard.html`، `requirements.txt`) را در یک ریپوی گیت‌هاب بگذارید.
2. به share.streamlit.io بروید، با گیت‌هاب وارد شوید و «Create app» را بزنید.
3. ریپو و برنچ را انتخاب کنید، فایل اصلی را `app.py` بگذارید و Deploy را بزنید.
4. لینک عمومی به شکل `https://<name>.streamlit.app` می‌گیرید که با همه قابل اشتراک است.
